"use client";

import { useMemo, useState } from "react";

type Product = { id: number; name: string; mrp: number; image: string };

const products: Product[] = [
  { id: 1, name: "Product 1", mrp: 499, image: "📱" },
  { id: 2, name: "Product 2", mrp: 799, image: "🎧" },
  { id: 3, name: "Product 3", mrp: 999, image: "⌨️" },
  { id: 4, name: "Product 4", mrp: 1499, image: "🖱️" }
];

export default function Home() {
  const [mobile, setMobile] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);
  const [cart, setCart] = useState<Record<number, number>>({});
  const [customerName, setCustomerName] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [status, setStatus] = useState("");
  const [sending, setSending] = useState(false);

  const items = useMemo(
    () => products.filter(p => (cart[p.id] || 0) > 0).map(p => ({ ...p, qty: cart[p.id] })),
    [cart]
  );
  const total = items.reduce((sum, p) => sum + p.mrp * p.qty, 0);

  function login() {
    if (!/^\d{10}$/.test(mobile)) {
      setStatus("Please enter a valid 10-digit mobile number.");
      return;
    }
    setLoggedIn(true);
    setStatus("");
  }

  function changeQty(id: number, delta: number) {
    setCart(prev => {
      const next = Math.max(0, (prev[id] || 0) + delta);
      const copy = { ...prev };
      if (next === 0) delete copy[id];
      else copy[id] = next;
      return copy;
    });
  }

  async function placeOrder() {
    if (!customerName.trim()) return setStatus("Please enter customer name.");
    if (!items.length) return setStatus("Please add at least one product.");
    setSending(true);
    setStatus("Order is being sent...");
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName,
          customerEmail,
          mobile,
          items,
          total
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Order failed");
      setStatus(`Order confirmed. Order ID: ${data.orderId}`);
      setCart({});
    } catch (e: any) {
      setStatus(e.message || "Could not send order.");
    } finally {
      setSending(false);
    }
  }

  if (!loggedIn) {
    return (
      <main className="loginPage">
        <section className="card loginCard">
          <div className="logo">HTW</div>
          <h1>Hitech World</h1>
          <p>Smart Products | Better Life</p>
          <h2>Customer Login</h2>
          <input
            inputMode="numeric"
            maxLength={10}
            placeholder="10-digit mobile number"
            value={mobile}
            onChange={e => setMobile(e.target.value.replace(/\D/g, ""))}
          />
          <button onClick={login}>Continue</button>
          {status && <div className="status">{status}</div>}
        </section>
      </main>
    );
  }

  return (
    <main>
      <header className="header">
        <div>
          <div className="brand">HTW <span>HITECH WORLD</span></div>
          <small>Smart Products | Better Life</small>
        </div>
        <div className="mobile">📞 {mobile}</div>
      </header>

      <section className="hero">
        <h1>Hitech World Product Catalog</h1>
        <p>Select products, choose quantity and confirm your order.</p>
      </section>

      <section className="grid">
        {products.map(p => (
          <article className="product card" key={p.id}>
            <div className="productIcon">{p.image}</div>
            <h3>{p.name}</h3>
            <strong>MRP ₹{p.mrp.toLocaleString("en-IN")}</strong>
            <div className="qty">
              <button onClick={() => changeQty(p.id, -1)}>-</button>
              <span>{cart[p.id] || 0}</span>
              <button onClick={() => changeQty(p.id, 1)}>+</button>
            </div>
          </article>
        ))}
      </section>

      <section className="checkout card">
        <h2>Order Confirmation</h2>
        <input placeholder="Customer name" value={customerName} onChange={e => setCustomerName(e.target.value)} />
        <input type="email" placeholder="Email (optional)" value={customerEmail} onChange={e => setCustomerEmail(e.target.value)} />
        <div className="summary">
          {items.length === 0 ? <p>No products selected.</p> : items.map(p =>
            <div className="row" key={p.id}><span>{p.name} × {p.qty}</span><span>₹{(p.mrp * p.qty).toLocaleString("en-IN")}</span></div>
          )}
          <div className="row total"><span>Total</span><span>₹{total.toLocaleString("en-IN")}</span></div>
        </div>
        <button className="orderBtn" disabled={sending} onClick={placeOrder}>
          {sending ? "Sending Order..." : "Confirm Order"}
        </button>
        {status && <div className="status">{status}</div>}
      </section>

      <footer>© {new Date().getFullYear()} Hitech World • Quality Products & Trusted Service</footer>
    </main>
  );
}