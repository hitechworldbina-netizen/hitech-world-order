import { NextResponse } from "next/server";
import nodemailer from "nodemailer";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { customerName, customerEmail, mobile, items, total } = body;

    if (!customerName || !mobile || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: "Missing order details." }, { status: 400 });
    }

    const required = ["SMTP_HOST", "SMTP_PORT", "SMTP_USER", "SMTP_PASS", "ORDER_TO_EMAIL"];
    const missing = required.filter(k => !process.env[k]);
    if (missing.length) {
      return NextResponse.json({ error: "Email service is not configured. Missing: " + missing.join(", ") }, { status: 500 });
    }

    const orderId = `HTW-${Date.now()}`;
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT),
      secure: Number(process.env.SMTP_PORT) === 465,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    });

    const lines = items.map((i: any) =>
      `<tr><td>${escapeHtml(i.name)}</td><td>${i.qty}</td><td>₹${Number(i.mrp).toLocaleString("en-IN")}</td><td>₹${(Number(i.mrp) * Number(i.qty)).toLocaleString("en-IN")}</td></tr>`
    ).join("");

    const html = `
      <h2>New Hitech World Order</h2>
      <p><b>Order ID:</b> ${orderId}</p>
      <p><b>Customer:</b> ${escapeHtml(customerName)}<br/>
      <b>Mobile:</b> ${escapeHtml(mobile)}<br/>
      <b>Email:</b> ${escapeHtml(customerEmail || "Not provided")}</p>
      <table border="1" cellpadding="8" cellspacing="0">
        <tr><th>Item</th><th>Qty</th><th>MRP</th><th>Amount</th></tr>
        ${lines}
      </table>
      <p><b>Total: ₹${Number(total).toLocaleString("en-IN")}</b></p>
    `;

    await transporter.sendMail({
      from: process.env.SMTP_USER,
      to: process.env.ORDER_TO_EMAIL,
      subject: `Hitech World Order ${orderId}`,
      html
    });

    if (customerEmail) {
      await transporter.sendMail({
        from: process.env.SMTP_USER,
        to: customerEmail,
        subject: `Hitech World Order Confirmation ${orderId}`,
        html
      });
    }

    return NextResponse.json({ ok: true, orderId });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Unable to send order email." }, { status: 500 });
  }
}

function escapeHtml(value: string) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[c] as string));
}