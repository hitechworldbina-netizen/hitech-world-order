import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Hitech World | Product Catalog",
  description: "Hitech World customer ordering catalog",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}