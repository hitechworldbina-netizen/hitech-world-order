# Hitech World Customer Ordering Catalog

Features:
- Chrome/mobile-friendly product catalog
- Customer login using 10-digit mobile number
- Product name, MRP and quantity
- Cart and order confirmation
- Email notification to Hitech World
- Optional customer confirmation email
- Works with Vercel + Gmail SMTP

## 1. Add your products
Edit `app/page.tsx` and replace the sample `products` list with your real products.

## 2. Gmail email setup
Use a Google App Password for `SMTP_PASS`; do not put your normal Gmail password in the project.

Set these Vercel environment variables:
- SMTP_HOST = smtp.gmail.com
- SMTP_PORT = 465
- SMTP_USER = hitechworldbina@gmail.com
- SMTP_PASS = your 16-character Google App Password
- ORDER_TO_EMAIL = hitechworldbina@gmail.com

## 3. Run locally
```bash
npm install
npm run dev
```

Open the localhost URL in Chrome.

## 4. Deploy to Vercel
Upload this project to GitHub and import it into Vercel, or deploy from the project folder with the Vercel CLI. Add the environment variables before testing an order.

## Important
This starter uses a static product list. For a large catalog or admin panel, connect a database later.
